require("dotenv").config();
const express = require("express");
const path = require("path");
const app = express();
const hbs = require("hbs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const auth = require("./middleware/auth");
const fs = require('fs');
const cheerio = require('cheerio');

require("./db/conn");
const Register = require("./models/register");
const { log } = require("console");
const port = process.env.PORT || 3000;
// console.log(path.join(__dirname, "../public"));
const static_path = path.join(__dirname, "../public");
const templates_path = path.join(__dirname, "../templates/views");
const partials_path = path.join(__dirname, "../templates/partials");

app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));

app.use(express.static(static_path));
app.set("view engine", "hbs");
app.set("views", templates_path);
hbs.registerPartials(partials_path);

// console.log(process.env.SECRET_KEY);

app.get("/", (req, res) => {
    res.render("index");
});
app.get("/game", (req, res) => {
    res.render("game");
    
});

app.post("/game", (req, res)=>{
    // const htmlContent = fs.readFileSync('templates/views/game.hbs', 'utf-8');
    // const $ = cheerio.load(htmlContent);
    // const divText = $('#user-score').text();
    // const match = divText.match(/\b([0-9]|10)\b/);
    // console.log(htmlContent);
    // console.log(divText);
    // console.log(match);
    // if (match) {
    //     const parsedNumber = parseInt(match[0], 10);
    //     const token = req.cookies.jwt;
    //     const verifyUser = jwt.verify(token, process.env.SECRET_KEY);
    //     const user = Register.findOne({_id:verifyUser._id});
    //     user.score = parsedNumber;
    //     console.log(user.score);
    //     console.log(parsedNumber);
    //     req.user.save();
    // } else {
    //     console.log("No number between 0 and 10 found in the div. game post");
    // }
    res.render("main");
})
app.get("/leaderboard", auth, (req, res) => {
    
    Register.find({})
        .then((registers) => {
            res.render("leaderboard", { registers });
            // console.log(registers);
        })
        .catch((con) => {
            console.log(con);
        });

    // console.log(`jwt cookie: ${req.cookies.jwt}`);
});

app.get("/signout", auth, async (req, res) => {
    try {
        // for single signout
        // req.user.tokens = req.user.tokens.filter((currentElement)=>{
        //     return currentElement.token !== req.token;
        // })

        // for signout from all devices
        // req.user.tokens = [];

        res.clearCookie("jwt");
        console.log("Signout successfull");
        await req.user.save();
        res.render("index");
    } catch (error) {
        res.status(500).send(error);
    }
});
app.get("/register", (req, res) => {
    res.render("register");
});
app.get("/main", (req, res) => {
    res.render("main");
});

//register
app.post("/register", async (req, res) => {
    try {
        const password = req.body.password;
        const confirmPassword = req.body.confirmPassword;
        if (password === confirmPassword) {
            const userRegister = new Register({
                username: req.body.username,
                email: req.body.email,
                password: req.body.password,
            });

            // console.log("Success Part:" + userRegister);
            const token = await userRegister.generateAuthToken();
            // console.log("Token Part: " + token);
            res.cookie("jwt", token, {
                expires: new Date(Date.now() + 600000),
                httpOnly: true,
            });
            const registered = await userRegister.save();
            res.status(201).render("login");
        } else {
            res.send("Password does not match");
        }
    } catch (error) {
        res.status(400).send(error);
        console.log("Error Part Page");
    }
});
app.get("/login", (req, res) => {
    res.render("login");
});

// login
app.post("/login", async (req, res) => {
    try {
        const email = req.body.email;
        const password = req.body.password;
        const userEmail = await Register.findOne({ email: email });
        const isMatch = await bcrypt.compare(password, userEmail.password);
        const token = await userEmail.generateAuthToken();
        // console.log("Token Part: " + token);
        res.cookie("jwt", token, {
            // expires: new Date(Date.now() + 600000),
            httpOnly: true,
        });

        if (isMatch) {
            res.status(201).render("main");
            //     console.log(`Logged in`);
        } else {
            res.send("Invalid");
        }
    } catch (error) {
        res.status(400).send("Invalid Credentials");
    }
});
app.listen(port, () => {
    console.log(`Server connected at port ${port}`);
});
