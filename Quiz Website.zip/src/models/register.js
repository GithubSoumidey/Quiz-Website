const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    time: {
        type: String
    },
    score: {
        type: String
    },
    tokens:[{
        token:{
            type: String,
            required: true
        }
    }]

})

//generating tokens
userSchema.methods.generateAuthToken = async function(){
    try {
        // console.log(this._id);
        const token = jwt.sign({_id:this._id.toString()}, process.env.SECRET_KEY);
        this.tokens = this.tokens.concat({token:token});
        await this.save();
        return token;
    } catch (error) {
        res.send("token part Error");
        console.log("token part Error:" + error);
    }
}

userSchema.pre("save", async function(next){
    
    if (this.isModified("password")) {
        this.password = await bcrypt.hash(this.password, 12);
        this.time = "-";
        this.score = "0";
    }
    next();
})

const Register = new mongoose.model("Register", userSchema);
module.exports = Register;

