const form = document.querySelector('form');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = new FormData(form);

        try {
            const response = await fetch('/login', {
                method: 'POST',
                body: formData,
            });

            if (response.status === 200) {
                // Successful login, redirect or show success message
                window.location.href = '/main';
            } else if (response.status === 401) {
                // Incorrect credentials, show alert
                alert('Incorrect username or password');
            } else {
                // Handle other errors
                alert('An error occurred');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    });